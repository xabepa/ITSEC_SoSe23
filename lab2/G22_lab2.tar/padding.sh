#!/bin/bash
python3 ./padding_oracle.py